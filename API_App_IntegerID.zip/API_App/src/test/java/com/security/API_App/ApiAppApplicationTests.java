package com.security.API_App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
