package com.security.API_App.token;

public enum TokenType {
  BEARER
}
