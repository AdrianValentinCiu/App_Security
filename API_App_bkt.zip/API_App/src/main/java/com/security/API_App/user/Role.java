package com.security.API_App.user;

public enum Role {
    USER,
    ADMIN
}
